# empty-project

Empty project.

## Building and running on localhost

First install dependencies:

```sh
yarn
```

To create a production build:

```sh
yarn build-prod
```

To create a development build:

```sh
yarn build-dev
```

## Running

```sh
yarn start
```

## Credits

Luca Moroni 2022
